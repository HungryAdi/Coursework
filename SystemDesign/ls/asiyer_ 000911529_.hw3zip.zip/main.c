#include "my_ls.h"

int main(int argc, char* argv[])
{
	do_ls(argc,argv);
	return 0;
}
